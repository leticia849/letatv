// Importando o React
import React, { Component } from 'react';
// Importando o Component Header
import Header from './components/header/header'
// Importando o component Main
import Main from './main'
import api from './api'

class App extends Component {
  state = {
    curso: [],
  }
  async componentDidMount() {
    const response = await api.get();
    this.setState({curso: response.data });
  }
  render() {
    const {curso} = this.state;
    return (
      <div>
        <Header />
        <Main curso={curso}/>
      </div>
    );
  }
}

export default App;