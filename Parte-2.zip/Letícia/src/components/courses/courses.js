// Importando o React
import React from "react";
import {NavLink} from 'react-router-dom';
// Importando os components necessários da lib react-materialize
import Curso from "./curso"


const Courses = (props) => {
    return (
        <div>
            <div class="row">
                <div>
                  <h5>Cursos</h5>
                  <NavLink to="/formulario"><a class="grey waves-effect waves-light btn">Adicionar</a></NavLink>
                </div>
              {props.curso.map(curso => (
                <Curso
                  nome={curso.nome}
                  descricao={curso.descricao} />
              ))};
            </div>
        </div>
    );
};

export default Courses;